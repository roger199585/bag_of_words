import os

ROOT = os.environ.get('ROOT', "/home/dinosaur/refactor/bag_of_words")
RESULT_PATH = os.environ.get('RESULT_PATH', '..')

os.makedirs(ROOT, exists_ok=True)
os.makedirs(RESULT_PATH, exists_ok=True)
